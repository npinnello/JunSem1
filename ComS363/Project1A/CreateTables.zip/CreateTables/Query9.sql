SELECT name, snum, ssn
FROM students
WHERE name BETWEEN 'Becky' AND 'Nicole'
ORDER BY name;
