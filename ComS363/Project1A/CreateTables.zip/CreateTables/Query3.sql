SELECT number, name
FROM courses
WHERE department_code = 401
ORDER BY number;
