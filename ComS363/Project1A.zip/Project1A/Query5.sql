SELECT name, level
FROM degrees
WHERE department_code = 401
ORDER BY level;
